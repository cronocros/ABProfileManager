local _, ns = ...

local SilvermoonMapOverlay = {}
ns.UI.SilvermoonMapOverlay = SilvermoonMapOverlay

local FONT_PATH = STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
local REFRESH_INTERVAL = 0.25
local CATEGORY_COLORS = {
    service = { 1.00, 0.87, 0.42 },
    travel = { 0.50, 0.92, 1.00 },
    profession = { 0.55, 1.00, 0.78 },
    pvp = { 1.00, 0.44, 0.44 },
}

local function getMapCanvasParent()
    if not WorldMapFrame or not WorldMapFrame.ScrollContainer then
        return nil
    end

    return WorldMapFrame.ScrollContainer.Child
        or WorldMapFrame.ScrollContainer.Canvas
        or WorldMapFrame.ScrollContainer
end

local function getPointColor(category)
    local color = CATEGORY_COLORS[category] or CATEGORY_COLORS.service
    return color[1], color[2], color[3]
end

function SilvermoonMapOverlay:Initialize()
    if self.driver then
        return
    end

    local driver = CreateFrame("Frame")
    driver:SetScript("OnUpdate", function(_, elapsed)
        self.elapsed = (self.elapsed or 0) + elapsed
        if self.elapsed < REFRESH_INTERVAL then
            return
        end

        self.elapsed = 0
        self:Refresh()
    end)

    self.driver = driver
end

function SilvermoonMapOverlay:EnsureOverlayFrame()
    local parent = getMapCanvasParent()
    if not parent then
        return nil
    end

    if self.overlayFrame and self.overlayFrame:GetParent() ~= parent then
        self.overlayFrame:SetParent(parent)
        self.overlayFrame:ClearAllPoints()
        self.overlayFrame:SetAllPoints(parent)
        self.lastWidth = nil
        self.lastHeight = nil
    end

    if self.overlayFrame then
        return self.overlayFrame
    end

    local frame = CreateFrame("Frame", nil, parent)
    frame:SetAllPoints(parent)
    frame:SetFrameStrata("DIALOG")
    frame:SetFrameLevel(parent:GetFrameLevel() + 20)
    frame:EnableMouse(false)

    self.overlayFrame = frame
    self.labels = {}
    return frame
end

function SilvermoonMapOverlay:EnsureLabel(index)
    self.labels = self.labels or {}
    if self.labels[index] then
        return self.labels[index]
    end

    local label = self.overlayFrame:CreateFontString(nil, "OVERLAY")
    label:SetJustifyH("CENTER")
    label:SetJustifyV("MIDDLE")
    if label.SetShadowOffset then
        label:SetShadowOffset(1, -1)
        label:SetShadowColor(0, 0, 0, 0.9)
    end
    self.labels[index] = label
    return label
end

function SilvermoonMapOverlay:HideAll()
    if not self.overlayFrame then
        return
    end

    self.overlayFrame:Hide()
    for _, label in ipairs(self.labels or {}) do
        label:Hide()
    end
end

function SilvermoonMapOverlay:LayoutPoints(parent)
    local data = ns.Data and ns.Data.SilvermoonMapData
    if not data then
        self:HideAll()
        return
    end

    local width = parent:GetWidth() or 0
    local height = parent:GetHeight() or 0
    if width <= 0 or height <= 0 then
        self:HideAll()
        return
    end

    for index, point in ipairs(data.points or {}) do
        local label = self:EnsureLabel(index)
        local red, green, blue = getPointColor(point.category)
        label:ClearAllPoints()
        label:SetPoint(
            "TOPLEFT",
            parent,
            "TOPLEFT",
            ((point.x or 0) / 100) * width + (point.offsetX or 0),
            -(((point.y or 0) / 100) * height) + (point.offsetY or 0)
        )
        label:SetFont(FONT_PATH, point.size or 12, "OUTLINE")
        label:SetTextColor(red, green, blue, 1)
        label:SetText(ns.L(point.labelKey))
        label:Show()
    end

    for index = #(data.points or {}) + 1, #(self.labels or {}) do
        self.labels[index]:Hide()
    end
end

function SilvermoonMapOverlay:Refresh()
    if not ns.DB or not ns.DB:IsSilvermoonMapOverlayEnabled() then
        self:HideAll()
        return
    end

    if not WorldMapFrame or not WorldMapFrame:IsShown() or type(WorldMapFrame.GetMapID) ~= "function" then
        self:HideAll()
        return
    end

    local data = ns.Data and ns.Data.SilvermoonMapData
    local mapID = WorldMapFrame:GetMapID()
    if not data or not data.mapIDs or not data.mapIDs[mapID] then
        self:HideAll()
        return
    end

    local frame = self:EnsureOverlayFrame()
    local parent = getMapCanvasParent()
    if not frame or not parent then
        self:HideAll()
        return
    end

    local width = parent:GetWidth() or 0
    local height = parent:GetHeight() or 0
    if mapID ~= self.currentMapID or width ~= self.lastWidth or height ~= self.lastHeight then
        self.currentMapID = mapID
        self.lastWidth = width
        self.lastHeight = height
        self:LayoutPoints(parent)
    end

    frame:Show()
end
