local _, ns = ...

-- BIS 아이템 드롭 위치 데이터 (Midnight 시즌 1)
-- 자동 생성됨 (scripts/json_to_lua.py)

ns.Data = ns.Data or {}
ns.Data.BISItems = {

    [71] = {
        { dungeon = '세트', boss = '알 수 없음', itemID = 249952, slot = 'Helm', note = 'BIS' },
        { dungeon = 'The Voidspire Fallen King Salhadaar Boss Strategy Abilities', boss = '알 수 없음', itemID = 249337, slot = '목', note = 'BIS' },
        { dungeon = '세트', boss = '알 수 없음', itemID = 249950, slot = 'Shoulders', note = 'BIS' },
        { dungeon = 'Overview', boss = '알 수 없음', itemID = 239656, slot = '망토', note = 'BIS' },
        { dungeon = 'The Dreamrift Chimaerus Boss Strategy Abilities Rewards', boss = '알 수 없음', itemID = 249955, slot = '가슴', note = 'BIS' },
        { dungeon = 'Overview', boss = '알 수 없음', itemID = 237834, slot = 'Bracers', note = 'BIS' },
        { dungeon = '윈드러너 첨탑', boss = '알 수 없음', itemID = 251081, slot = 'Gloves', note = 'BIS' },
        { dungeon = 'Unknown', boss = '알 수 없음', itemID = 249949, slot = '허리', note = 'BIS' },
        { dungeon = '세트', boss = '알 수 없음', itemID = 249951, slot = '다리', note = 'BIS' },
        { dungeon = 'The Dreamrift Chimaerus Boss Strategy Abilities Rewards', boss = '알 수 없음', itemID = 249381, slot = 'Boots', note = 'BIS' },
        { dungeon = '마이드나잇 폭포', boss = '알 수 없음', itemID = 249920, slot = 'Ring', note = 'BIS' },
        { dungeon = '공결점 제나스', boss = '알 수 없음', itemID = 251217, slot = 'Ring', note = 'BIS' },
        { dungeon = 'The Dreamrift Chimaerus Boss Strategy Abilities Rewards', boss = '알 수 없음', itemID = 249343, slot = '장신구', note = 'BIS' },
        { dungeon = 'The Voidspire Vorasius Boss Strategy Abilities', boss = '알 수 없음', itemID = 249342, slot = '장신구', note = 'BIS' },
        { dungeon = '마이드나잇 폭포', boss = '알 수 없음', itemID = 249296, slot = 'Mainhand', note = 'BIS' },
    },

    [258] = {
        { dungeon = 'Raids Overview Hub Dates Locations', boss = '알 수 없음', itemID = 250051, slot = 'Helm', note = 'BIS' },
        { dungeon = '마이드나잇 폭포', boss = '알 수 없음', itemID = 250247, slot = '목', note = 'BIS' },
        { dungeon = 'Raids Overview Hub Dates Locations', boss = '알 수 없음', itemID = 250049, slot = 'Shoulders', note = 'BIS' },
        { dungeon = 'The Voidspire Vaelgor Ezzorak Boss Strategy Abilities', boss = '알 수 없음', itemID = 249370, slot = 'Cape', note = 'BIS' },
        { dungeon = 'Raids Overview Hub Dates Locations', boss = '알 수 없음', itemID = 250054, slot = '가슴', note = 'BIS' },
        { dungeon = '마법학자의 정원', boss = '알 수 없음', itemID = 251108, slot = 'Bracers', note = 'BIS' },
        { dungeon = 'Raids Overview Hub Dates Locations', boss = '알 수 없음', itemID = 250052, slot = 'Gloves', note = 'BIS' },
        { dungeon = 'March On Quel Danas Beloren Boss Strategy Abilities', boss = '알 수 없음', itemID = 249376, slot = '허리', note = 'BIS' },
        { dungeon = 'Raids Overview Hub Dates Locations', boss = '알 수 없음', itemID = 250050, slot = '다리', note = 'BIS' },
        { dungeon = 'The Dreamrift Chimaerus Boss Strategy Abilities Rewards', boss = '알 수 없음', itemID = 249373, slot = 'Boots', note = 'BIS' },
        { dungeon = '마이드나잇 폭포', boss = '알 수 없음', itemID = 249920, slot = 'Ring', note = 'BIS' },
        { dungeon = 'The Voidspire Lightblinded Vanguard Boss Strategy Abilities', boss = '알 수 없음', itemID = 249369, slot = 'Ring', note = 'BIS' },
        { dungeon = 'The Dreamrift Chimaerus Boss Strategy Abilities Rewards', boss = '알 수 없음', itemID = 249343, slot = 'Trinkets', note = 'BIS' },
        { dungeon = 'The Voidspire Vaelgor Ezzorak Boss Strategy Abilities', boss = '알 수 없음', itemID = 249346, slot = 'Trinkets', note = 'BIS' },
        { dungeon = 'March On Quel Danas Beloren Boss Strategy Abilities', boss = '알 수 없음', itemID = 249283, slot = '1h Weapon', note = 'BIS' },
        { dungeon = 'The Dreamrift Chimaerus Boss Strategy Abilities Rewards', boss = '알 수 없음', itemID = 249922, slot = 'Offhand', note = 'BIS' },
    },

    [269] = {
        { dungeon = '세트', boss = '알 수 없음', itemID = 250015, slot = '머리', note = 'BIS' },
        { dungeon = '마이드나잇 폭포', boss = '알 수 없음', itemID = 250247, slot = '목', note = 'BIS' },
        { dungeon = '세트', boss = '알 수 없음', itemID = 250013, slot = '어깨', note = 'BIS' },
        { dungeon = '세트', boss = '알 수 없음', itemID = 250010, slot = '망토', note = 'BIS' },
        { dungeon = '세트', boss = '알 수 없음', itemID = 250018, slot = '가슴', note = 'BIS' },
        { dungeon = 'The Voidspire Vorasius Boss Strategy Abilities', boss = '알 수 없음', itemID = 249327, slot = '손목', note = 'BIS' },
        { dungeon = 'The Voidspire Vaelgor Ezzorak Boss Strategy Abilities', boss = '알 수 없음', itemID = 249321, slot = '손', note = 'BIS' },
        { dungeon = '윈드러너 첨탑', boss = '알 수 없음', itemID = 251082, slot = '허리', note = 'BIS' },
        { dungeon = '세트', boss = '알 수 없음', itemID = 250014, slot = '다리', note = 'BIS' },
        { dungeon = '세트', boss = '알 수 없음', itemID = 250017, slot = '발', note = 'BIS' },
        { dungeon = 'Overview', boss = '알 수 없음', itemID = 251513, slot = 'Ring', note = 'BIS' },
        { dungeon = '마이드나잇 폭포', boss = '알 수 없음', itemID = 249920, slot = 'Ring', note = 'BIS' },
        { dungeon = '마이사라 동굴', boss = '알 수 없음', itemID = 251162, slot = '2H Weapon', note = 'BIS' },
        { dungeon = 'The Voidspire Crown Of The Cosmos Boss Strategy Abilities', boss = '알 수 없음', itemID = 260423, slot = '1H Weapon', note = 'BIS' },
        { dungeon = 'Overview', boss = '알 수 없음', itemID = 237845, slot = '1H Weapon', note = 'BIS' },
        { dungeon = 'The Dreamrift Chimaerus Boss Strategy Abilities Rewards', boss = '알 수 없음', itemID = 249343, slot = 'Trinket 1', note = 'BIS' },
        { dungeon = '알게타르 아카데미', boss = '알 수 없음', itemID = 193701, slot = 'Trinket 2', note = 'BIS' },
    },

}
