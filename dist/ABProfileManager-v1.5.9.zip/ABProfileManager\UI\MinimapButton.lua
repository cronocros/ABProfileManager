local _, ns = ...

local MinimapButton = {}
ns.UI.MinimapButton = MinimapButton

local function updatePosition(button)
    if not button or not Minimap then
        return
    end

    local config = ns.DB:GetMinimapConfig()
    local angle = math.rad(config.angle or 220)
    local radius = math.floor(((Minimap:GetWidth() or 140) * 0.5) + 4)
    local x = math.cos(angle) * radius
    local y = math.sin(angle) * radius

    button:ClearAllPoints()
    button:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

local function setTooltip(button)
    GameTooltip:SetOwner(button, "ANCHOR_LEFT")
    GameTooltip:SetText(ns.L("minimap_tooltip_title"))
    GameTooltip:AddLine(ns.L("minimap_tooltip_line1"), 1, 0.82, 0, true)
    GameTooltip:AddLine(ns.L("minimap_tooltip_line2"), 1, 0.82, 0, true)
    GameTooltip:AddLine(ns.L("minimap_tooltip_line3", ns.Constants.AUTHOR), 0.7, 0.9, 1, true)
    ns.UI.Widgets.ApplyTooltip(GameTooltip, 13, 12)
    GameTooltip:Show()
end

function MinimapButton:Initialize()
    if self.button or not Minimap then
        return
    end

    local button = CreateFrame("Button", "ABPM_MinimapButton", Minimap)
    button:SetSize(24, 24)
    button:SetFrameStrata("MEDIUM")
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    button:RegisterForDrag("RightButton")

    button.fill = button:CreateTexture(nil, "BACKGROUND")
    button.fill:SetAllPoints()
    button.fill:SetTexture("Interface\\Buttons\\WHITE8X8")
    button.fill:SetVertexColor(0.09, 0.13, 0.18, 0.96)

    button.ring = button:CreateTexture(nil, "ARTWORK")
    button.ring:SetPoint("TOPLEFT", 2, -2)
    button.ring:SetPoint("BOTTOMRIGHT", -2, 2)
    button.ring:SetTexture("Interface\\Buttons\\WHITE8X8")
    button.ring:SetVertexColor(0.72, 0.58, 0.24, 0.95)

    button.inner = button:CreateTexture(nil, "ARTWORK")
    button.inner:SetPoint("TOPLEFT", 4, -4)
    button.inner:SetPoint("BOTTOMRIGHT", -4, 4)
    button.inner:SetTexture("Interface\\Buttons\\WHITE8X8")
    button.inner:SetVertexColor(0.10, 0.16, 0.22, 0.98)

    button.label = button:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    button.label:SetPoint("CENTER", 0, -1)
    button.label:SetText("AB")
    button.label:SetTextColor(1, 0.84, 0.32, 1)
    ns.UI.Widgets.ApplyFont(button.label, 9, { domain = "ui" })

    button:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    button:SetHitRectInsets(-8, -8, -8, -8)

    button:SetScript("OnClick", function(_, mouseButton)
        if mouseButton == "LeftButton" then
            ns.UI.MainWindow:Toggle()
        end
    end)

    button:SetScript("OnDragStart", function(currentButton)
        local radius = math.floor(((Minimap:GetWidth() or 140) * 0.5) + 4)
        currentButton:SetScript("OnUpdate", function()
            local cursorX, cursorY = GetCursorPosition()
            local scale = Minimap:GetEffectiveScale()
            local centerX, centerY = Minimap:GetCenter()
            local offsetX = (cursorX / scale) - centerX
            local offsetY = (cursorY / scale) - centerY
            local angle = math.deg(math.atan2(offsetY, offsetX))
            -- 위치 직접 계산 (DB 읽기 없이)
            local rad = math.rad(angle)
            currentButton:ClearAllPoints()
            currentButton:SetPoint("CENTER", Minimap, "CENTER", math.cos(rad) * radius, math.sin(rad) * radius)
            currentButton._dragAngle = angle
        end)
    end)

    button:SetScript("OnDragStop", function(currentButton)
        currentButton:SetScript("OnUpdate", nil)
        -- 드래그 종료 시 한 번만 DB 저장 후 정규 위치 갱신
        if currentButton._dragAngle then
            ns.DB:SetMinimapAngle(currentButton._dragAngle)
            currentButton._dragAngle = nil
        end
        updatePosition(currentButton)
    end)

    button:SetScript("OnEnter", setTooltip)
    button:SetScript("OnLeave", GameTooltip_Hide)

    self.button = button
    self:Refresh()
end

function MinimapButton:Refresh()
    if not self.button then
        return
    end

    if ns.DB:GetMinimapConfig().hide then
        self.button:Hide()
        return
    end

    updatePosition(self.button)
    self.button:Show()
end
